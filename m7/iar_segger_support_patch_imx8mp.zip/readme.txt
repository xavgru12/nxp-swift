  About this patch
   =========================================
   JLink.zip provides the segger script support in JLink.
   arm.zip provides the debugging files in IAR toolchain. 


   MD5SUM:
     c367d475abb1c2c33d5e91ee59dc943e   arm.zip
     46eb8a4d976ae8a80366d198a24654b9   JLink.zip
   

   How to use this patch
   =========================================
   1.arm.zip

    Please unzip the arm.zip and override all the existing files in the arm folder in your IAR installer path. 
    For example, C:\Program Files (x86)\IAR Systems\Embedded Workbench 8.4\arm.
   
   2.JLink.zip
     a.Please install SEGGER software, which can be downloaded from www.segger.com/jlink-software.html.

     b.Please unzip the JLink.zip and override all the existing files in the JLink folder in your SEGGER installer path. 
    For example, C:\Program Files (x86)\SEGGER\JLink.